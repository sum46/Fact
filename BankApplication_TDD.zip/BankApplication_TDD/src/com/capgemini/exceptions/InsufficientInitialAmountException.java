package com.capgemini.exceptions;

public class InsufficientInitialAmountException extends Exception {

}
